#!/usr/bin/env bash
set -euo pipefail

echo "🧰 apt update + ffmpeg"
sudo apt-get update -y
sudo apt-get install -y ffmpeg

echo "🐍 upgrade pip"
python -m pip install --upgrade pip setuptools wheel

echo "📦 install deps (CPU)"
pip install -r requirements.txt

echo "✅ setup done."
